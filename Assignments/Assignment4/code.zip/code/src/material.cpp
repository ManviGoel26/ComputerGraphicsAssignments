#include "world.h"
#include "material.h"

Color Material::shade(const Ray& incident, const bool isSolid) const
{
	return color;
}
